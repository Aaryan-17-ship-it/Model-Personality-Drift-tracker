@echo off
title Model Personality Drift Tracker (Web/Mobile View)
echo ===================================================
echo Starting Model Personality Drift Tracker in Chrome...
echo ===================================================
flutter run -d chrome
pause
