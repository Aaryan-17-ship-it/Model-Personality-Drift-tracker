@echo off
title Model Personality Drift Tracker (Windows Desktop)
echo =======================================================
echo Starting Model Personality Drift Tracker on Windows...
echo =======================================================
flutter run -d windows
pause
